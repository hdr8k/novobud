@extends('nova::layout')

@section('content')
Dashboard Content
@endsection
