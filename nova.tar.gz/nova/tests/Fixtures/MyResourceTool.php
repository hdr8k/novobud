<?php

namespace Laravel\Nova\Tests\Fixtures;

use Laravel\Nova\ResourceTool;

class MyResourceTool extends ResourceTool
{
}
